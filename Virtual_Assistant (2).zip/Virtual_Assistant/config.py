# config.py

# API Key for Weather Service
API_KEY = "145b59d4137d50e4fc8bb7bacc495c31"

# Log File Path
LOG_FILE = "logs/app.log"

# Reminder Storage File
REMINDER_FILE = "database/reminders.txt"
