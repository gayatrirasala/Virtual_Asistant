import logging
from modules.calculator import Calculator
from modules.weather import get_weather
from modules.reminder import Reminder
from gui.interface import run_gui
from config import API_KEY

def main():
    logging.basicConfig(filename="logs/app.log", level=logging.INFO,
                        format="%(asctime)s - %(levelname)s - %(message)s")
    
    print("Welcome to Virtual Assistant!")
    while True:
        print("\nOptions:")
        print("1. Calculator")
        print("2. Weather")
        print("3. Set Reminder")
        print("4. GUI Mode")
        print("5. Exit")
        choice = input("Enter your choice: ")
        
        if choice == "1":
            calc = Calculator()
            num1 = float(input("Enter first number: "))
            num2 = float(input("Enter second number: "))
            op = input("Enter operation (+, -, *, /): ")
            result = calc.calculate(num1, num2, op)
            print(f"Result: {result}")
        
        elif choice == "2":
            city = input("Enter city name: ")
            print(get_weather(city, API_KEY))
        
        elif choice == "3":
            task = input("Enter task: ")
            time = input("Enter time (HH:MM format): ")
            Reminder().set_reminder(task, time)
        
        elif choice == "4":
            run_gui()
        
        elif choice == "5":
            print("Goodbye!")
            break
        
        else:
            print("Invalid choice! Please try again.")

if __name__ == "__main__":
    main()
