import sqlite3

def setup_database():
    conn = sqlite3.connect("database/assistance.db")
    cursor = conn.cursor()
    
    # Create tables for storing calculations, reminders, and logs
    cursor.execute('''CREATE TABLE IF NOT EXISTS calculations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        num1 REAL,
                        num2 REAL,
                        operation TEXT,
                        result REAL,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                    )''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS reminders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        task TEXT,
                        reminder_time TEXT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                    )''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        log_message TEXT,
                        log_level TEXT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                    )''')
    
    conn.commit()
    conn.close()
    print("Database setup complete.")

if __name__ == "__main__":
    setup_database()
