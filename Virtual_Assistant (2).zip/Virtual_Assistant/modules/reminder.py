# reminder.py
import time
import threading
import logging
from config import REMINDER_FILE

class Reminder:
    def __init__(self):
        self.reminders = []

    def set_reminder(self, task, reminder_time):
        reminder_entry = f"Reminder set for {reminder_time}: {task}\n"
        self.reminders.append((task, reminder_time))
        
        with open(REMINDER_FILE, "a") as file:
            file.write(reminder_entry)
        
        logging.info(f"New Reminder: {task} at {reminder_time}")
        print(f"Reminder set: {task} at {reminder_time}")
        
        threading.Thread(target=self.wait_for_reminder, args=(task, reminder_time)).start()

    def wait_for_reminder(self, task, reminder_time):
        time_parts = list(map(int, reminder_time.split(':')))
        target_seconds = time_parts[0] * 3600 + time_parts[1] * 60
        
        while True:
            current_time = time.localtime()
            current_seconds = current_time.tm_hour * 3600 + current_time.tm_min * 60
            
            if current_seconds >= target_seconds:
                print(f"Reminder Alert: {task}")
                logging.info(f"Reminder Triggered: {task}")
                break
            time.sleep(30)
