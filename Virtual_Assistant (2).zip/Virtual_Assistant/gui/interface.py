# gui/interface.py
import tkinter as tk
from tkinter import messagebox
from modules.calculator import Calculator
from modules.weather import get_weather
from modules.reminder import Reminder
from config import API_KEY

def calculate():
    num1 = float(entry_num1.get())
    num2 = float(entry_num2.get())
    op = operation_var.get()
    result = calc.calculate(num1, num2, op)
    result_label.config(text=f"Result: {result}")

def get_weather_info():
    city = entry_city.get()
    weather_info = get_weather(city, API_KEY)
    messagebox.showinfo("Weather Info", weather_info)

def set_reminder():
    task = entry_task.get()
    time = entry_time.get()
    reminder.set_reminder(task, time)
    messagebox.showinfo("Reminder Set", f"Reminder for '{task}' set at {time}")

def run_gui():
    global entry_num1, entry_num2, operation_var, result_label, entry_city, entry_task, entry_time
    
    root = tk.Tk()
    root.title("Virtual Assistant GUI")
    root.geometry("400x500")
    
    tk.Label(root, text="Calculator").pack()
    entry_num1 = tk.Entry(root)
    entry_num1.pack()
    entry_num2 = tk.Entry(root)
    entry_num2.pack()
    operation_var = tk.StringVar()
    operation_var.set("+")
    tk.OptionMenu(root, operation_var, "+", "-", "*", "/").pack()
    tk.Button(root, text="Calculate", command=calculate).pack()
    result_label = tk.Label(root, text="Result: ")
    result_label.pack()
    
    tk.Label(root, text="Weather").pack()
    entry_city = tk.Entry(root)
    entry_city.pack()
    tk.Button(root, text="Get Weather", command=get_weather_info).pack()
    
    tk.Label(root, text="Reminder").pack()
    entry_task = tk.Entry(root)
    entry_task.pack()
    entry_time = tk.Entry(root)
    entry_time.pack()
    tk.Button(root, text="Set Reminder", command=set_reminder).pack()
    
    root.mainloop()

calc = Calculator()
reminder = Reminder()

if __name__ == "__main__":
    run_gui()