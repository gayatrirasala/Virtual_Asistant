# weather.py
import requests
from config import API_KEY

def get_weather(city, api_key=API_KEY):
    try:
        url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
        response = requests.get(url)
        data = response.json()
        
        if response.status_code == 200:
            weather = data['weather'][0]['description']
            temp = data['main']['temp']
            return f"Weather in {city}: {weather}, Temperature: {temp}°C"
        else:
            return "Error: City not found"
    except Exception as e:
        return f"Error: {e}"
