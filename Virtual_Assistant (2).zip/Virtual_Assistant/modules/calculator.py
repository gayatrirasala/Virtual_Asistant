# calculator.py

class Calculator:
    def calculate(self, num1, num2, operation):
        try:
            if operation == '+':
                return num1 + num2
            elif operation == '-':
                return num1 - num2
            elif operation == '*':
                return num1 * num2
            elif operation == '/':
                if num2 == 0:
                    return "Error: Division by zero"
                return num1 / num2
            else:
                return "Invalid operation"
        except Exception as e:
            return f"Error: {e}"
